﻿SELECT MEL_Id, firstName,middleName,lastName,passportNumber, 
            passportExpirationDate,phoneNumber,address, landlordName, landlordPhoneNumber FROM MELPeople