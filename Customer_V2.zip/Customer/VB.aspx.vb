﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Web.Services
Imports System.IO
Imports Word = Microsoft.Office.Interop.Word

Partial Class VB
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Me.BindDummyRow()
        End If
    End Sub

    Private Sub BindDummyRow()
        Dim dummy As New DataTable()
        dummy.Columns.Add("MEL_Id")
        dummy.Columns.Add("firstName")
        dummy.Columns.Add("middleName")
        dummy.Columns.Add("lastName")
        dummy.Columns.Add("passportNumber")
        dummy.Columns.Add("passportExpirationDate")
        dummy.Columns.Add("phoneNumber")
        dummy.Columns.Add("address")
        dummy.Columns.Add("landlordName")
        dummy.Columns.Add("landlordPhoneNumber")
        dummy.Rows.Add()
        gvMELPeople.DataSource = dummy
        gvMELPeople.DataBind()
    End Sub

    <WebMethod()>
    Public Shared Function GetMELPeople() As String
        Dim query As String = "SELECT MEL_Id, firstName,middleName,lastName,passportNumber, " _
            & "passportExpirationDate,phoneNumber,address, landlordName, landlordPhoneNumber FROM MELPeople"
        'MsgBox(query)
        Dim cmd As New SqlCommand(query)
        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        Using con As New SqlConnection(constr)
            Using sda As New SqlDataAdapter()
                cmd.Connection = con
                sda.SelectCommand = cmd
                Using ds As New DataSet()
                    sda.Fill(ds)
                    Return ds.GetXml()
                End Using
            End Using
        End Using
    End Function

    <WebMethod()>
    Public Shared Function InsertMELRecord(name As String, country As String) As Integer
        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        'MsgBox("MS Word Code here")
        Using con As New SqlConnection(constr)
            'TODO add new columns
            Using cmd As New SqlCommand("INSERT INTO MELPeople VALUES(@Name, @Country) SELECT SCOPE_IDENTITY()")
                cmd.Parameters.AddWithValue("@Name", name)
                cmd.Parameters.AddWithValue("@Country", country)
                cmd.Connection = con
                con.Open()
                Dim MEL_Id As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                con.Close()
                Return MEL_Id
            End Using
        End Using
        StartMSWord(name)

    End Function

    <WebMethod()>
    Public Shared Sub UpdateMELRecord(MEL_Id As Integer, name As String, country As String)
        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        Using con As New SqlConnection(constr)
            'TODO add new columns
            Using cmd As New SqlCommand("UPDATE MELPeople SET Name = @Name, Country = @Country WHERE MEL_Id = @MEL_Id")
                cmd.Parameters.AddWithValue("@MEL_Id", MEL_Id)
                cmd.Parameters.AddWithValue("@Name", name)
                cmd.Parameters.AddWithValue("@Country", country)
                cmd.Connection = con
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub

    <WebMethod()>
    Public Shared Sub DeleteMELRecord(MEL_Id As Integer)
        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("DELETE FROM MELPeople WHERE MEL_Id = @MEL_Id")
                cmd.Parameters.AddWithValue("@MEL_Id", MEL_Id)
                cmd.Connection = con
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub

    Public Shared Sub StartMSWord(txtFirstName As String)
        'lblMisc.Text = txtFirstName.Text
        Dim word_app As Word._Application = New Word.ApplicationClass()
        ' Make Word visible (optional).
        word_app.Visible = True
        ' Create the Word document.
        Dim word_doc As Word._Document =
        word_app.Documents.Add()
        ' Create a header paragraph.
        Dim para As Word.Paragraph = word_doc.Paragraphs.Add()
        'para.Range.Text = "Chrysanthemum Curve"
        'para.Range.Style = "Heading 1"
        'para.Range.InsertParagraphAfter()
        'Add more text.
        'para.Range.Text = "To make a chrysanthemum curve, use" &
        '"the following " &
        '"parametric equations as t goes from 0 to 21 * ? to" &
        '    "generate " &
        '"points and then connect them."
        'para.Range.InsertParagraphAfter()
        'Save the current font And start using Courier New.
        Dim old_font As String = para.Range.Font.Name
        'para.Range.Font.Name = "Courier New"
        ' Add the equations.
        para.Range.Text =
        "Dear " & txtFirstName & " " & vbCrLf &
        " here is line one" & vbCrLf &
        "this is line 2" & vbCrLf &
        vbCrLf & vbCrLf & vbCrLf &
        "This is the last line" & vbCrLf
        ' Start a new paragraph and then switch back to the
        ' original font.
        para.Range.InsertParagraphAfter()
        para.Range.Font.Name = old_font
        ' Save the document.
        'Dim filename As Object = Path.GetFullPath(txtLastName.Text & "test.doc")
        'word_doc.SaveAs(FileName:=filename)
        '' Close.
        'Dim save_changes As Object = False
        'word_doc.Close(save_changes)
        'word_app.Quit(save_changes)

    End Sub
    Protected Sub gvMELPeople_SelectedIndexChanged(sender As Object, e As EventArgs) Handles gvMELPeople.SelectedIndexChanged

    End Sub
End Class
