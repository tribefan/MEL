﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Web.Services
Imports System.IO
Imports Word = Microsoft.Office.Interop.Word

Partial Class VB
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Me.BindDummyRow()
        End If
    End Sub

    Private Sub BindDummyRow()
        Dim dummy As New DataTable()
        dummy.Columns.Add("CustomerId")
        dummy.Columns.Add("Name")
        dummy.Columns.Add("Country")
        dummy.Rows.Add()
        gvCustomers.DataSource = dummy
        gvCustomers.DataBind()
    End Sub

    <WebMethod()> _
    Public Shared Function GetCustomers() As String
        Dim query As String = "SELECT CustomerId, Name, Country FROM Customers"
        Dim cmd As New SqlCommand(query)
        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        Using con As New SqlConnection(constr)
            Using sda As New SqlDataAdapter()
                cmd.Connection = con
                sda.SelectCommand = cmd
                Using ds As New DataSet()
                    sda.Fill(ds)
                    Return ds.GetXml()
                End Using
            End Using
        End Using
    End Function

    <WebMethod()>
    Public Shared Function InsertCustomer(name As String, country As String) As Integer
        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        'MsgBox("MS Word Code here")
        StartMSWord(name)
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("INSERT INTO Customers VALUES(@Name, @Country) SELECT SCOPE_IDENTITY()")
                cmd.Parameters.AddWithValue("@Name", name)
                cmd.Parameters.AddWithValue("@Country", country)
                cmd.Connection = con
                con.Open()
                Dim customerId As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                con.Close()
                Return customerId
            End Using
        End Using
    End Function

    <WebMethod()> _
    Public Shared Sub UpdateCustomer(customerId As Integer, name As String, country As String)
        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("UPDATE Customers SET Name = @Name, Country = @Country WHERE CustomerId = @CustomerId")
                cmd.Parameters.AddWithValue("@CustomerId", customerId)
                cmd.Parameters.AddWithValue("@Name", name)
                cmd.Parameters.AddWithValue("@Country", country)
                cmd.Connection = con
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub

    <WebMethod()>
    Public Shared Sub DeleteCustomer(customerId As Integer)
        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("DELETE FROM Customers WHERE CustomerId = @CustomerId")
                cmd.Parameters.AddWithValue("@CustomerId", customerId)
                cmd.Connection = con
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub

    Public Shared Sub StartMSWord(txtFirstName As String)
        'lblMisc.Text = txtFirstName.Text
        Dim word_app As Word._Application = New Word.ApplicationClass()
        ' Make Word visible (optional).
        word_app.Visible = True
        ' Create the Word document.
        Dim word_doc As Word._Document =
        word_app.Documents.Add()
        ' Create a header paragraph.
        Dim para As Word.Paragraph = word_doc.Paragraphs.Add()
        'para.Range.Text = "Chrysanthemum Curve"
        'para.Range.Style = "Heading 1"
        'para.Range.InsertParagraphAfter()
        'Add more text.
        'para.Range.Text = "To make a chrysanthemum curve, use" &
        '"the following " &
        '"parametric equations as t goes from 0 to 21 * ? to" &
        '    "generate " &
        '"points and then connect them."
        'para.Range.InsertParagraphAfter()
        'Save the current font And start using Courier New.
        Dim old_font As String = para.Range.Font.Name
        'para.Range.Font.Name = "Courier New"
        ' Add the equations.
        para.Range.Text =
        "Dear " & txtFirstName & " " & vbCrLf &
        " here is line one" & vbCrLf &
        "this is line 2" & vbCrLf &
        vbCrLf & vbCrLf & vbCrLf &
        "This is the last line" & vbCrLf
        ' Start a new paragraph and then switch back to the
        ' original font.
        para.Range.InsertParagraphAfter()
        para.Range.Font.Name = old_font
        ' Save the document.
        'Dim filename As Object = Path.GetFullPath(txtLastName.Text & "test.doc")
        'word_doc.SaveAs(FileName:=filename)
        '' Close.
        'Dim save_changes As Object = False
        'word_doc.Close(save_changes)
        'word_app.Quit(save_changes)

    End Sub
End Class
